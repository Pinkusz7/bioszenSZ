library(testthat)
library(MiApp)

test_check("MiApp")
